﻿

// test.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#pragma comment(lib, "opencv_world450d.lib")  //引用引入库 


#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
void show_wait_destroy(const char* winname, cv::Mat img);
using namespace std;
using namespace cv;
int main(int argc, char** argv)
{
#ifdef _DEBUG
	Mat src = imread( "test.jpg",IMREAD_COLOR);
#else  
	CommandLineParser parser(argc, argv, "{@input | notes.png | input image}");
	Mat src = imread(samples::findFile(parser.get<String>("@input")), IMREAD_COLOR);
#endif
	if (src.empty())
	{
		cout << "Could not open or find the image!\n" << endl;
		cout << "Usage: " << argv[0] << " <Input image>" << endl;
		return -1;
	}
	// Show source image
	imshow("src", src);
	// Transform source image to gray if it is not already
	Mat gray;
	if (src.channels() == 3)
	{
		cvtColor(src, gray, COLOR_BGR2GRAY);
	}
	else
	{
		gray = src;
	}
 
	show_wait_destroy("gray", gray);
	// Apply adaptiveThreshold at the bitwise_not of gray, notice the ~ symbol
	Mat bw;
	adaptiveThreshold(~gray, bw, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 15, -2);
 
	show_wait_destroy("binary", bw);
 
	Mat horizontal = bw.clone();
	Mat vertical = bw.clone();
 
	int horizontal_size = horizontal.cols / 30;
 
	Mat horizontalStructure = getStructuringElement(MORPH_RECT, Size(horizontal_size, 1));
 
	erode(horizontal, horizontal, horizontalStructure, Point(-1, -1));
	dilate(horizontal, horizontal, horizontalStructure, Point(-1, -1));
 
	show_wait_destroy("horizontal", horizontal);
 
	int vertical_size = vertical.rows / 30;
 
	Mat verticalStructure = getStructuringElement(MORPH_RECT, Size(1, vertical_size));
 
	erode(vertical, vertical, verticalStructure, Point(-1, -1));
	dilate(vertical, vertical, verticalStructure, Point(-1, -1));
	// Show extracted vertical lines
	show_wait_destroy("vertical", vertical);
	// Inverse vertical image
	bitwise_not(vertical, vertical);
	show_wait_destroy("vertical_bit", vertical);
	 
	Mat edges;
	adaptiveThreshold(vertical, edges, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 3, -2);
	show_wait_destroy("edges", edges);
 
	Mat kernel = Mat::ones(2, 2, CV_8UC1);
	dilate(edges, edges, kernel);
	show_wait_destroy("dilate", edges);
 
	Mat smooth;
	vertical.copyTo(smooth);
 
	blur(smooth, smooth, Size(2, 2));
 
	smooth.copyTo(vertical, edges);
	// Show final result
	show_wait_destroy("smooth - final", vertical);
	return 0;
}
void show_wait_destroy(const char* winname, cv::Mat img) {
	imshow(winname, img);
	moveWindow(winname, 500, 0);
	waitKey(0);
	destroyWindow(winname);
}