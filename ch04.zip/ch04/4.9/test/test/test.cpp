﻿// test.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include <opencv2/opencv.hpp>
using namespace cv;
#include<iostream>
using namespace std;
#pragma comment(lib, "opencv_world450d.lib")  //引用引入库 
int main()
{
	RNG rng((unsigned)time(NULL));
	int N1 = rng;
	cout << hex << "N1=0x" << N1 << endl;

	double a = rng.uniform(0, 1);
	double b = rng.uniform((double)0, (double)1);
	double c = rng.uniform(0.f, 1.f);
	double d = rng.uniform(0., 1.);
	double g = rng.gaussian(2);
	cout << "a="<<a <<",b=" << b << ",c="<<c <<",d="<< d << ",g="<< g << endl;
	system("pause");
}