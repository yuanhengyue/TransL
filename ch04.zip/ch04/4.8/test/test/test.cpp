﻿// test.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include <iostream>
#include <opencv2/core.hpp>

int main()
{
	cv::RNG rng;  
	int N1 = rng();  
	printf("N=0x%x\n", N1);
}

 