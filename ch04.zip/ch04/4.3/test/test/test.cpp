﻿// test.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include <iostream>
#include <opencv2\imgproc\types_c.h> //for CV_RGB2GRAY
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp> 
#pragma comment(lib, "opencv_world450d.lib")  //引用引入库 
using namespace std;
using namespace cv;

int main(int argc, char** argv)
{
	//绘制奥迪Audi车标
	Mat image2 = Mat::zeros(500, 850, CV_8UC3);
	
	circle(image2, Point(447, 63), 63, (0, 0, 255), -1);   
	circle(image2, Point(200, 300), 100, Scalar(225, 0, 225), 7, 8); 
	circle(image2, Point(350, 300), 100, Scalar(225, 0, 225), 7, 8); 
	circle(image2, Point(500, 300), 100, Scalar(225, 0, 225), 7, 8); 
	circle(image2, Point(650, 300), 100, Scalar(225, 0, 225), 7, 8); 
	imshow("奥迪车标", image2);
	waitKey();
	return 0;
}
 