﻿// test.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include <iostream>
#include <opencv2\imgproc\types_c.h> //for CV_RGB2GRAY
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp> 
#pragma comment(lib, "opencv_world450d.lib")  //引用引入库 
using namespace std;
using namespace cv;

int main()
{
	Mat	image3 = Mat::zeros(120, 120, CV_8UC3); 
	Rect rec1 = Rect(10 , 30 , 60, 20);  
	Rect rec2 = Rect(30, 10, 20, 60);  
	rectangle(image3, rec1, Scalar(0, 0, 255), -1, 8, 0); 
	rectangle(image3, rec2, Scalar(0, 0, 255), -1, 8, 0); 
	rectangle(image3, Point(10 , 30), Point(70 , 50 ), Scalar(0, 255, 255), 2, 8, 0); 
	rectangle(image3, Point(30 , 10), Point(50 , 70), Scalar(0, 255, 255), 2, 8, 0); 
	rectangle(image3, Point(30, 30), Point(50, 50), Scalar(0, 0, 255), 3, 8); 
	imshow("红十字", image3);
	waitKey();
	return 0;
}