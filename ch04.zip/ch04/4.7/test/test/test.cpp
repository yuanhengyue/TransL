﻿
// test.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include<iostream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#pragma comment(lib, "opencv_world450d.lib")  //引用引入库 
using namespace cv;

void scalar_demo1() 
{
	Mat blue_m(256, 256, CV_8UC3, Scalar(255, 0, 0));
	Mat green_m(256, 256, CV_8UC3, Scalar(0, 255, 0));
	Mat red_m(256, 256, CV_8UC3, Scalar(0, 0, 255));
	imshow("Blue", blue_m);
	waitKey(1000);
	imshow("Green", green_m);
	waitKey(1000);
	imshow("Red", red_m);
	waitKey(1000);

}

int scalar_demo2()
{
	cv::Scalar scalar(125);
	cv::Mat mat(2, 3, CV_8UC1, scalar);
	std::cout << mat << std::endl;
	std::cout << std::endl;

	cv::Scalar scalar1(0, 255);
	cv::Mat mat1(4, 4, CV_32FC2, scalar1);
	std::cout << mat1 << std::endl;
	std::cout << std::endl;

	cv::Scalar scalar2(0, 255, 255);
	cv::Mat mat2(4, 4, CV_32FC3, scalar2);
	std::cout << mat2 << std::endl;
	std::cout << std::endl;

	cv::Scalar scalar3(0, 255, 255, 0);
	cv::Mat mat3(4, 4, CV_32FC4, scalar3);
	std::cout << mat3 << std::endl;
	return 0;
}

int main()
{
	scalar_demo1();
	scalar_demo2();
}