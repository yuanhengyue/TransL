﻿#include "pch.h"
#include <opencv2/opencv.hpp>  //头文件
#include <iostream>

#pragma comment(lib, "opencv_world450d.lib")  //引用引入库 

using namespace cv;  //包含cv命名空间
using namespace std;

int main(int argc, char ** argv)
{
	Mat srcImage, dstImage;
	 
	 
	float alpha = 2.0;
	float beta = 0;
	  
	 
	srcImage = imread("img.jpg", 0);     
	if (!srcImage.data)
	{
		printf("could not load image...\n");
		return -1;
	}
	char input_title[] = "input image";
	char output_title[] = "output image";
	namedWindow(input_title, WINDOW_AUTOSIZE);
	namedWindow(output_title, WINDOW_AUTOSIZE);

 
	imshow(input_title, srcImage);

	dstImage = srcImage.clone();	 

	 
	for (int r = 0; r < srcImage.rows; r++)
	{
		for (int c = 0; c < srcImage.cols; c++) {
			uchar temp = srcImage.at<uchar>(r, c);
			if (temp < 50)
			{
				dstImage.at<uchar>(r, c) = saturate_cast<uchar>(temp * 0.5);	 
			}
			else if (50 <= temp && temp < 150)
			{
				dstImage.at<uchar>(r, c) = saturate_cast<uchar>(temp * 3.6 - 310);	 
			}
			else
			{
				dstImage.at<uchar>(r, c) = saturate_cast<uchar>(temp * 0.238 + 194);	 
			}
		}
	}

 
	imshow(output_title, dstImage);
	imwrite("img_new.jpg", dstImage);		 

 
	waitKey(0);
	return 0;
}
 