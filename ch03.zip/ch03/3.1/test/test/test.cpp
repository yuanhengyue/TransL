﻿// test.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include <iostream>
#include<opencv2/opencv.hpp>
#include <opencv2\imgproc\types_c.h>

using namespace cv;  //所有opencv类都在命名空间cv下
using namespace std;

#pragma comment(lib, "opencv_world450d.lib")  //引用引入库 


//绘制灰度直方图
int main()
{
	Mat src, gray;
	src = imread("p1.jpg");
	if (src.empty()) //判断原图是否加载成功
	{
		cout << "图像加载失败" << endl;
		return -1;
	}

	cvtColor(src, gray, CV_RGB2GRAY);
	int bins = 256;
	int hist_size[] = { bins };
	float range[] = { 0, 256 };
	const float* ranges[] = { range };
	MatND hist;
	int channels[] = { 0 };
	//使用ocv自带函数计算灰度直方图
	calcHist(&gray, 1, channels, Mat(), // do not use mask
		hist, 1, hist_size, ranges,
		true, // the histogram is uniform
		false);

	//画出直方图
	double max_val;
	minMaxLoc(hist, 0, &max_val, 0, 0);
	int scale = 2;
	int hist_height = 256;
	Mat hist_img = Mat::zeros(hist_height, bins*scale, CV_8UC3);
	for (int i = 0; i < bins; i++)
	{
		float bin_val = hist.at<float>(i);
		int intensity = cvRound(bin_val*hist_height / max_val);  //要绘制的高度
		rectangle(hist_img, Point(i*scale, hist_height - 1),
			Point((i + 1)*scale - 1, hist_height - intensity),
			CV_RGB(255, 255, 255));
	}
	//显示原图和直方图
	imshow("原图片", src);
	imshow("灰度直方图", hist_img);
	waitKey(10000000000);
	return 0;
}
 