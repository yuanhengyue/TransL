﻿#include "pch.h"
#include <opencv2/core/core.hpp>              
#include <opencv2/highgui/highgui.hpp>              
#include <opencv2/imgproc/imgproc.hpp>                
#include <opencv2\imgproc\types_c.h>
#pragma comment(lib, "opencv_world450d.lib")  

using namespace cv;

int main()
{
	//------------【1】读取源图像并检查图像是否读取成功------------    
	Mat srcImage = imread("build.jpg");
	if (!srcImage.data)
	{
		puts("读取图片错误，请重新输入正确路径!");
		system("pause");
		return -1;
	}
	imshow("【源图像】", srcImage);
	//------------【2】灰度转换------------    
	Mat srcGray;
	cvtColor(srcImage, srcGray, CV_RGB2GRAY);
	imshow("【灰度图】", srcGray);
	//------------【3】初始化相关变量---------------  
	Mat dstImage;        //初始化自适应阈值参数
	const int maxVal = 255;
	int blockSize = 3;    //取值3、5、7....等
	int constValue = 10;
	int adaptiveMethod = 0;
	int thresholdType = 1;
	//---------------【4】图像自适应阈值操作-------------------------
	adaptiveThreshold(srcGray, dstImage, maxVal, adaptiveMethod, thresholdType, blockSize, constValue);

	imshow("【自适应阈值】", dstImage);
	waitKey(0);
	return 0;
}