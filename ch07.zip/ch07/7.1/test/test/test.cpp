﻿// test.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include <iostream>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/core/core.hpp>
#include <iostream>

#pragma comment(lib, "opencv_world450d.lib")  //引用引入库 

//平移操作，图像大小不变
cv::Mat imageTranslation1(cv::Mat & srcImage, int x0ffset, int y0ffset)
{
	int nRows = srcImage.rows;
	int nCols = srcImage.cols;
	cv::Mat resultImage(srcImage.size(), srcImage.type());
	//遍历图像
	for (int i = 0; i < nRows; i++)
	{
		for (int j = 0; j < nCols; j++)
		{
		
			int x = j - x0ffset;
			int y = i - y0ffset;
			//边界判断
			if (x >= 0 && y >= 0 && x < nCols && y < nRows)
			{
				resultImage.at<cv::Vec3b>(i, j) = srcImage.ptr<cv::Vec3b>(y)[x]; 
			}
		}
	}
	return resultImage;
}
//平移操作，图形大小改变
cv::Mat imageTranslation2(cv::Mat & srcImage, int x0ffset, int y0ffset)
{
	//设置平移尺寸
	int nRows = srcImage.rows + abs(y0ffset);
	int nCols = srcImage.cols + abs(x0ffset);
	cv::Mat resultImage(nRows, nCols, srcImage.type());
	//图像遍历
	for (int i = 0; i < nRows; i++)
	{
		for (int j = 0; j < nCols; j++)
		{
			int x = j - x0ffset;
			int y = i - y0ffset;
			//边界判断
			if (x >= 0 && y >= 0 && x < nCols && y < nRows)
			{
				resultImage.at<cv::Vec3b>(i, j) = srcImage.ptr<cv::Vec3b>(y)[x]; 
			}
		}
	}
	return resultImage;
}

int main()
{
	//读取图像
	cv::Mat srcImage = cv::imread("img.jpg");
	if (srcImage.empty())
	{
		return -1;
	}

	//显示原图像
	cv::imshow("原图像", srcImage);
	int x0ffset = 50;
	int y0ffset = 80;
	cv::Mat resultImage1 = imageTranslation1(srcImage, x0ffset, y0ffset);
	cv::imshow("resultImage1", resultImage1);
	cv::Mat resultImage2 = imageTranslation2(srcImage, x0ffset, y0ffset);
	cv::imshow("resultImage2", resultImage2);
	x0ffset = -50;
	y0ffset = -80;
	cv::Mat resultImage3 = imageTranslation1(srcImage, x0ffset, y0ffset);
	cv::imshow("resultImage3", resultImage3);
	cv::waitKey(0);
	return 0;
}