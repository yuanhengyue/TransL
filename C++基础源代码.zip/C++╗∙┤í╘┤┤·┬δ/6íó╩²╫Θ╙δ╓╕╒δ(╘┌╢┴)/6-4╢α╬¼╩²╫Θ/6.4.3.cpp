#include <iostream>
using namespace std;
// ��ά���������
int main() 
{
	int arr1[3][3] = { {0, 1, 2}, 
	                   {3, 4, 5}, 
	                   {6, 7, 8} };
	cout << "arr1: " << arr1 << endl;
	for ( int i = 0; i < 3; i++ ) 
	{
		cout << "arr1[" << i << "]: " << arr1[i] << endl;
		for ( int j = 0; j < 3; j++ ) 
		{
			cout << arr1[i][j] << " ";
		}
		cout << endl;
	}
	return 0;
}