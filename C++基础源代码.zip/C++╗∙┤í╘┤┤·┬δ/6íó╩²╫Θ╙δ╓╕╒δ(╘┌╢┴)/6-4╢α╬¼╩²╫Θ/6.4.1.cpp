#include <iostream>
using namespace std;
// ��ά����Ĵ���
int main() 
{
	int arr1[3][3] = { {0, 1, 2}, 
	                   {3, 4, 5}, 
	                   {6, 7, 8} };
	int arr2[3][3] = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };
	int arr3[2][2][2] = { { {0, 1}, 
	                        {2, 3} }, 
	                    { {4, 5}, 
	                      {6, 7} } };
	return 0;
}