#include <iostream>
using namespace std;
// ʹ��malloc
int main() 
{
	int *arr = (int*)malloc(5 * sizeof(int));
	int *ptr = arr;
	for ( int i = 0; i < 5; i++ ) 
	{
		*ptr = i;
		cout << *ptr << " "; 
		ptr++; // Ҳ����ֱ��д�� cout << *(ptr++) << " ";
	}
	cout << endl;
	free(arr);
	arr = NULL;
	return 0;
}