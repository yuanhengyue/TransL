#include <iostream>
using namespace std;
// ʹ��new��delete
int main() 
{
	int *numPtr = new int(3);
	cout << *numPtr << endl;
	delete numPtr;
	int *arr = new int[5];
	int *ptr = arr;
	for ( int i = 0; i < 5; i++ ) 
	{
		*ptr = i;
		cout << *ptr << " "; 
		ptr++; // Ҳ����ֱ��д�� cout << *(ptr++) << " ";
	}
	cout << endl;
	delete [] arr;
	arr = NULL;
	return 0;
}