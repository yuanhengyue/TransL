#include <iostream>
using namespace std;
// ����ĳ�ʼ���б�
int main() 
{
	int arr1[5] = { 0, 1, 2, 3, 4 };
	int arr2[5] = { 0, 1, 2 };
	int arr3[] = { 0, 1, 2, 3, 4 };
	return 0;
}