#include <iostream>
using namespace std;
// ����Ĳ���
int main() 
{
	int arr1[5] = { 0, 1, 2, 3, 4 };
	int arr2[5] = { 0, 1, 2 };
	int arr3[] = { 0, 1, 2, 3, 4 };
	for ( int i = 0; i < 5; i++ ) 
	{
		cout << arr1[i] << " ";
	}
	cout << endl;
	for ( int i = 0; i < 5; i++ ) 
	{
		cout << arr2[i] << " ";
	}
	cout << endl;
	for ( int i = 0; i < 5; i++ ) 
	{
		cout << arr3[i] << " ";
	}
	cout << endl;
	return 0;
}