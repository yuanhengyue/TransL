#include <iostream>
using namespace std;
// ����Ĵ���
int main() 
{
	int arr1[2];
	const int constNum = 4;
	float arr2[constNum];
	int arr3[constNum + 1];
	int num = 5;
	char arr4[num];
	return 0;
}