#include <iostream>
using namespace std;
// ָ��ĺ���
int main() 
{
	int arr[5] = { 0, 1, 2, 3, 4 };
	int *ptr = arr;
	for ( int i = 0; i < 5; i++ ) 
	{
		cout << *ptr << " ";
		cout << "��ַ��" << ptr << endl;
		ptr++;
	}
	return 0;
}