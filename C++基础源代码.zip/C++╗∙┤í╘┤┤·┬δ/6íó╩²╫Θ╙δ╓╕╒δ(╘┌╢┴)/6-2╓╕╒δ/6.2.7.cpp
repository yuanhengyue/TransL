#include <iostream>
using namespace std;
// ָ�����
int main() 
{
	int arr[5] = { 0, 1, 2, 3, 4 };
	int *ptr1 = arr + 1;
	int *ptr2 = arr + 3;
	cout << "ptr1��" << ptr1 << endl;
	cout << "ptr2��" << ptr2 << endl;
	cout << "ptr2 - ptr1��" << ptr2 - ptr1 << endl;
	cout << "ptr1 - ptr2��" << ptr1 - ptr2 << endl;
	return 0;
}