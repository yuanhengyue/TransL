#include <iostream>
using namespace std;
// ָ���ָ��
int main() 
{
	int num = 3;
	int *numPtr = &num;
	int **numPtrPtr = &numPtr;
    cout << "num: " << num << endl;
	cout << "*numPtr: " << *numPtr << endl;
	cout << "numPtr: " << numPtr << endl;
	cout << "*numPtrPtr: " << *numPtrPtr << endl;
	cout << "numPtrPtr: " << numPtrPtr << endl;
	return 0;
}