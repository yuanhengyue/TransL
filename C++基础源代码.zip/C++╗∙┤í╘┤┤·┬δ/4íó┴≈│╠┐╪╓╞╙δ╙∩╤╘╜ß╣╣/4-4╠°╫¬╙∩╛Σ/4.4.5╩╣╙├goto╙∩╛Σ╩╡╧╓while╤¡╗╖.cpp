#include <iostream>
using namespace std;
// ʹ��goto���ʵ��whileѭ��
int main() {
	int i = 0;
loopHead:
	if ( i >= 10 )
		goto loopEnd;
	cout << i << endl;
	i++;
	goto loopHead;
loopEnd:
	return 0;
}