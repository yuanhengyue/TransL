#include <iostream>
using namespace std;
//switch���Ĺᴩ
int main() {
	int num = 6;
	switch ( num ) 
	{
	case 0:
		cout << "��" << endl;
		break;
	case 1:
		cout << "һ" << endl;
		break;
	case 2:
		cout << "��" << endl;
		break;
	case 3:
		cout << "��" << endl;
		break;
	case 4:
		cout << "��" << endl;
		break;
	case 5:
		cout << "��" << endl;
		break;
	case 6:
		cout << "��" << endl;
	case 7:
		cout << "��" << endl;
		break;
	case 8:
		cout << "��" << endl;
		break;
	case 9:
		cout << "��" << endl;
		break;
	default:
		cout << "���ֲ���0-9��Χ�ڣ�" << endl;
		break;
	}
	return 0;
}