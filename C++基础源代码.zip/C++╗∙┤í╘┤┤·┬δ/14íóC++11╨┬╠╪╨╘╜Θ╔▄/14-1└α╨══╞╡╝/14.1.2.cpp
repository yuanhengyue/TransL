#include <iostream>
using namespace std;
// ����ʹ��auto������
int max(auto a, int b) 
{
	return a > b ? a : b;
}
class myclass 
{
public:
	auto val;
};
int main() 
{
	auto num;
	auto arr[5] = { 1, 2, 3, 4, 5 };
	return 0;
}