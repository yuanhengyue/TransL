#include <iostream>
#include <vector>
using namespace std;
// declType���÷�
int main() 
{
	vector<int> vec(3, 0);
    typedef decltype(vec.begin()) ItType;
	ItType it;
	for ( it = vec.begin(); it != vec.end(); it++ ) 
	{
		cout << *it << " ";
	}
	cout << endl;
	return 0;
}

