#include <iostream>
#include <vector>
using namespace std;
// ��auto���������
int main() 
{
	cout << "��ӡvector��" << endl;
	vector<vector<int>> vecVec = { {0, 1}, {1, 2}, {2, 3}, {3, 4}, {4, 5} };
	for ( const auto &vec : vecVec ) 
	{
		for ( const auto &num : vec ) 
		{
			cout << num << " ";
		}
		cout << endl;
	}
	return 0;
}



