#include <iostream>
#include <vector>
#include <set>
using namespace std;

// �������
int main() 
{
	cout << "��ӡ���飺" << endl;
	int arr[5] = { 0, 1, 2, 3, 4 };
	for ( int num : arr ) 
	{
		cout << num << " ";
	}
	cout << endl;
	cout << "��ӡvector��" << endl;
	vector<int> vec = { 0, 1, 2, 3, 4 };
	for ( int num : vec ) 
	{
		cout << num << " ";
	}
	cout << endl;
	cout << "��ӡset��" << endl;
	set<int> set1;
	set1.insert(3);
	set1.insert(1);
	set1.insert(2);
	for ( int num : set1 ) 
	{
		cout << num << " ";
	}
	cout << endl;
	return 0;
}