#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
// Lambda����ʽ
int main() 
{
	vector<int> vec = { 3,5,7,4,8,9,0,2,1,6 };
	cout << "��ӡvector��" << endl;
	for ( int i = 0; i < vec.size(); i++ ) 
	{
		cout << vec[i] << " ";
	}
	cout << endl;
	sort(vec.begin(), vec.end(), [](int a, int b) { return a > b; });
	cout << "��ӡ������vector��" << endl;
	for ( int i = 0; i < vec.size(); i++ ) 
	{
		cout << vec[i] << " ";
	}
	cout << endl;
	return 0;
}