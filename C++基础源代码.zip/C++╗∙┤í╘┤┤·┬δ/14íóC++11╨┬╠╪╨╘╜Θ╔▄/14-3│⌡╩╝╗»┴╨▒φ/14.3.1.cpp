#include <iostream>
#include <vector>
using namespace std;
// �������ʼ��vector
int main() 
{
	cout << "��ӡvector��" << endl;
	int myints[] = { 10, 20, 30, 30, 20 };
    std::vector<int> vec(myints, myints+5);
	for ( const auto &num : vec ) 
	{
		cout << num << " ";
	}
	cout << endl;
	return 0;
}