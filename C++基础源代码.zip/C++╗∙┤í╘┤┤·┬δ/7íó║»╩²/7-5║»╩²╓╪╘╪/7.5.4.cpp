#include <iostream>
using namespace std;

// ���ؽ���
int add(int a, int b, int c) { return a + b + c; }
int add(int a, int b) { return a + b; }
float add(float a, float b) { return a + b; }

int main() 
{
	float a = 3.5f;
	float b = 4.5f;
	cout << "a + b = " << add(a, b) << endl;
	return 0;
}
