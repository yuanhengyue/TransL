#include <iostream>
using namespace std;
// ����ָ��
int *allocIntArr(int size) 
{
	int *ret = (int*)malloc(size * sizeof(int));
	return ret;
}

void releaseIntArr(int *intArr) 
{
	delete intArr;
}

int main() 
{
	int size = 5;
	int *intArr = allocIntArr(size);
	for ( int i = 0; i < size; i++ ) 
	{
		intArr[i] = i;
	}
	for ( int i = 0; i < size; i++ ) 
	{
		cout<< "��ӡ�����" << i << "��Ԫ�أ�" << intArr[i] << endl;
	}
	releaseIntArr(intArr);
	return 0;
}