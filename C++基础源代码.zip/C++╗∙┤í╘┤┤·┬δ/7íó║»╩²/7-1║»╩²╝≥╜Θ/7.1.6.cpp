#include <iostream>
using namespace std;
// �β�ʵ�β�ƥ��
void doSomething(int a) 
{
}

void doNothing() 
{
}

int main() 
{
	doSomething();
	doNothing(3);
	return 0;
}