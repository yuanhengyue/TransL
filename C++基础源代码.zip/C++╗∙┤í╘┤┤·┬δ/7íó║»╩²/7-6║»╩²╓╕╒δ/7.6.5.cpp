#include <iostream>
using namespace std;
// ����ָ����Ϊ����ֵ
int (*funcRetFp(int a, int b))(int, int) 
{
	int(*fp)( int, int ) = NULL;
	return fp;
}
typedef int(*binaryFp)(int, int);
binaryFp funcRetFpTypedef(int a, int b) 
{
	binaryFp fp = NULL;
	return fp;
}
int main() 
{
	cout << funcRetFp(1, 2) << " " << funcRetFpTypedef(1, 2) << endl;
	return 0;
}