#include <iostream>
using namespace std;
// ����ָ��Ĵ���
int min(int a, int b) 
{
	return a < b ? a : b;
}

int main() 
{
	int (*fpIntInt)(int, int);
	fpIntInt = min;
	int (*fpInt)(int);
	fpInt = min;
	return 0;
}