#include <iostream>
using namespace std;
// ��typedef�򻯺���ָ��Ķ���
int min(int a, int b) 
{
	return a < b ? a : b;
}

int max(int a, int b) 
{
	return a > b ? a : b;
}

int main() 
{
	typedef int (*fpIntInt)(int, int);
	fpIntInt fpMin = min;
	fpIntInt fpMax = max;
	return 0;
}