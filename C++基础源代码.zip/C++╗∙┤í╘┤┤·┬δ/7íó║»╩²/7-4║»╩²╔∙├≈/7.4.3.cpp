
#include "7.4.3.h"
int max(int a, int b) 
{
	return a > b ? a : b;
}

