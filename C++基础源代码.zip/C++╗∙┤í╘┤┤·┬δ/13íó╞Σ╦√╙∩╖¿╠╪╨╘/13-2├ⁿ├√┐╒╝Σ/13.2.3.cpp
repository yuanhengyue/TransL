#include <iostream>
using namespace std;
// Ƕ�������ռ�

// ��ѧ��
namespace myMath 
{
	// ��ֵ�ӿ�
	namespace minmax 
	{
		int min(int a, int b) 
		{
			return a < b ? a : b;
		}
		int max(int a, int b) 
		{
			return a > b ? a : b;
		}
	}
	// �����ӿ�
	namespace arithmetic 
	{
		int add(int a, int b) 
		{
			return a + b;
		}
		int mul(int a, int b) 
		{
			return a * b;
		}
	}
}

int main() 
{
	int a = 3;
	int b = 5;
	cout << "min(a, b) = " << myMath::minmax::min(a, b) << endl;
	cout << "max(a, b) = " << myMath::minmax::max(a, b) << endl;
	cout << "a + b = " << myMath::arithmetic::add(a, b) << endl;
	cout << "a * b = " << myMath::arithmetic::mul(a, b) << endl;
	return 0;
}