#include <iostream>
#include <string>
#include <limits.h>
using namespace std;
// �����쳣����
class Char 
{
public:
	Char(char v) : val(v) {}
	char getValue() const { return val; }
protected:
	char val;
};

class overflow : public runtime_error 
{
public:
	overflow(const string &str, 
		     char l, 
		     char r) : runtime_error(str), left(l), right(r) {}
	char getLeft() const { return left; }
	char getRight() const { return right; }
private:
	char left;
	char right;
};

Char operator+ (const Char &a, const Char &b) 
{
	short sum = a.getValue() + b.getValue();
	if ( sum > CHAR_MAX ) 
	{
		throw overflow("�����˼ӷ������", a.getValue(), b.getValue());
	}	
	return Char(a.getValue() + b.getValue());
}

int main() {
	Char c0(124);
	Char c1(5);
	try 
	{
		Char c2 = c0 + c1;
	} 
	catch ( const overflow &e ) 
	{
		cerr << (int)e.getLeft() << "��" << (int)e.getRight() << e.what() << endl;
		cout << "������һ��" << endl;
	}
	return 0;
}