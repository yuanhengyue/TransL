#include <iostream>
using namespace std;
// �׳��쳣
class Integer 
{
public:
	Integer(int v) : val(v) {}
	int getValue() const { return val; }
protected:
	int val;
};

Integer operator/ (const Integer &a, const Integer &b) 
{
	if ( b.getValue() == 0 )
		throw runtime_error("0���ܵ���������");
	return Integer(a.getValue() / b.getValue());
}
int main() 
{
	Integer int1(1);
	Integer int0(0);
	Integer int2(2);
	try 
	{
		int2 = int1 / int0;
	} 
	catch ( const runtime_error &e ) 
	{
		cerr << e.what() << endl;
		cout << "������һ��" << endl;
	}
	return 0;
}