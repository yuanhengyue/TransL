#include <iostream>
using namespace std;
// private���캯��
// Author: ��Ҽ��ѧ
class MyClass
{
public:
	static MyClass* buildMyClass(int v) 
	{
		return (new MyClass(v));
	}
	static void destroyMyClass(MyClass *ptr) 
	{
		delete ptr;
	}
	void printVal() const { cout << "val��ֵΪ��" << val << endl; }
	
private:
	MyClass(int v): val(v) {}
	MyClass(const MyClass &myclass): val(myclass.val) {}
	~MyClass() {}
	int val;
};
void printMyClass( const MyClass &myclass) 
{
	myclass.printVal();
}
// ���ƹ��캯��Ϊ˽�У������ٰ�ֵ����
/*void printMyClass( MyClass myclass) {
	myclass.printVal();
}*/
int main()
{
	MyClass *p = MyClass::buildMyClass(2);
	printMyClass(*p);
	MyClass::destroyMyClass(p);
	return 0;
}