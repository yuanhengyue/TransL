#include <iostream>
using namespace std;
// ����ĸ�ֵ
class Component 
{
public:
	Component(int v) : val(v) {}
	int getVal() { return val; }
private:
	int val;
};


class MyClass 
{
public:
	MyClass(Component cp) : comp(cp) {}
	void print() 
	{
		cout << "comp��valֵΪ��" << comp.getVal() << endl;
	}
private:
	Component comp;
};



int main() 
{
	Component comp1(1);
	MyClass myclass1(comp1);
	myclass1.print();
	cout << "���и�ֵ��" << endl;
	Component comp2(2);
	MyClass myclass2(comp2);
	myclass2 = myclass1;
	myclass2.print();
	return 0;
}