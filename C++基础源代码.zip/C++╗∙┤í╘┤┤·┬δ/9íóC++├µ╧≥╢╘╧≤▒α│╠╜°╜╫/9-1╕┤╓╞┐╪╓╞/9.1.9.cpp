#include <iostream>
using namespace std;
// ��ֹ����
class Component 
{
public:
	Component(int v) : val(v) {}
	int getVal() { return val; }
private:
	int val;
};
class MyClass 
{
public:
	MyClass(Component cp) : comp(cp) {}
private:
	MyClass(const MyClass &myclass) : comp(myclass.comp) 
	{
		cout << "���ƹ��캯��" << endl;
	}
	Component comp;
};
int main() 
{
	Component comp(1);
	MyClass myclass1(comp);
	MyClass myclass2(myclass1);
	return 0;
}