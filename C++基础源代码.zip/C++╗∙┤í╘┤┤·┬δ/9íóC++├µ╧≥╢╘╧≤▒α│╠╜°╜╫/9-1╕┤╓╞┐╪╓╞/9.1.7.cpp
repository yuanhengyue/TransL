#include <iostream>
using namespace std;
// ��ֵ����������
class Component 
{
public:
	Component(int v) : val(v) {}
	int getVal() { return val; }
private:
	int val;
};


class MyClass 
{
public:
	MyClass(int val) 
	{
		compPtr = new Component(val);
	}
	~MyClass() 
	{
		delete compPtr;
	}
	MyClass& operator=(const MyClass &rhs) 
	{
		*compPtr = *rhs.compPtr;
		return *this;
	}
	void print() 
	{
		cout << "comp��valֵΪ��" << compPtr->getVal() << endl;
		cout << "compPtr��ֵΪ��" << compPtr << endl;
	}
private:
	Component *compPtr;
};



int main() 
{
	MyClass myclass1(1);
	myclass1.print();
	MyClass myclass2(2);
	myclass2.print();
	cout << "���и�ֵ��" << endl;
	myclass2 = myclass1;
	myclass2.print();
	return 0;
}