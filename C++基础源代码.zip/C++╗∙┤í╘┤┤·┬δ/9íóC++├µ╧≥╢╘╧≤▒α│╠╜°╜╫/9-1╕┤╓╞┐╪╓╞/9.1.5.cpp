#include <iostream>
using namespace std;
// ���
class Component 
{
public:
	Component(int v) : val(v) {}
	int getVal() { return val; }
private:
	int val;
};



class MyClass 
{
public:
	MyClass(Component cp, Component *cpPtr) : comp(cp), compPtr(cpPtr) {}
	MyClass(const MyClass &myclass) : comp(myclass.comp) 
	{
		this->compPtr = new Component(*myclass.compPtr);
	}
	~MyClass() 
	{
		delete compPtr;
	}
	void print() 
	{
		cout << "comp��valֵΪ��" << comp.getVal() << endl;
		cout << "compPtr�ĵ�ַΪ��" << compPtr << endl;
		cout << "compPtrָ������valֵΪ��" << compPtr->getVal() << endl;
	}
private:
	Component comp;
	Component *compPtr;
};



MyClass test(MyClass myclass) 
{
	return myclass;
}


int main() 
{
	Component comp1(1);
	Component comp2(3);
	MyClass myclass1(comp1, &comp2);
	myclass1.print();
	cout << "����test��" << endl;
	test(myclass1).print();
	return 0;
}