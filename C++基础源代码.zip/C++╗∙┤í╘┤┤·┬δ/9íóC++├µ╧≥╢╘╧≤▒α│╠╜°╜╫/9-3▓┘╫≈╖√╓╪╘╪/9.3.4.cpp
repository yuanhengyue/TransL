#include <iostream>
#include <vector>
#include <algorithm> // sort��������Ҫ������ͷ�ļ�
using namespace std;
// ��ϵ������

// ����
class Interval
{
public:
	Interval(int s, int e) : start(s), end(e) {}
	int start;
	int end;
};
bool operator<(const Interval &lhs, const Interval &rhs) 
{
	if ( lhs.start < rhs.start ) 
	{
		return true;
	} 
	else if ( lhs.start == rhs.start ) 
	{
		return (lhs.end < rhs.end);
	} 
	else 
	{
		return false;
	}
}

int main() 
{
	vector<Interval> intervals;
	intervals.push_back(Interval(4, 6));
	intervals.push_back(Interval(1, 3));
	intervals.push_back(Interval(1, 2));
	intervals.push_back(Interval(2, 3));
	sort(intervals.begin(), intervals.end());
	for ( int i = 0; i < intervals.size(); i++ ) 
	{
		cout << "x��" << intervals[i].start << " y��" << intervals[i].end << endl;
	}
	return 0;
}