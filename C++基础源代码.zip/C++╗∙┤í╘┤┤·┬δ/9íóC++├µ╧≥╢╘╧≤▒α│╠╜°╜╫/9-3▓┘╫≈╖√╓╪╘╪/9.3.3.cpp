#include <iostream>
using namespace std;
// ����������

// ��ά����
class Vector2D
{
public:
	Vector2D(int X, int Y) : x(X), y(Y) {}
	int x;
	int y;
};
Vector2D operator+(const Vector2D &lhs, const Vector2D &rhs) 
{
	Vector2D res(lhs.x + rhs.x, lhs.y + rhs.y);
	return res;
}
Vector2D operator-(const Vector2D &lhs, const Vector2D &rhs) 
{
	Vector2D res(lhs.x - rhs.x, lhs.y - rhs.y);
	return res;
}
// ��������
Vector2D operator*(const Vector2D &lhs, int rhs) 
{
	Vector2D res(lhs.x * rhs, lhs.y * rhs);
	return res;
}
Vector2D operator*(int lhs, const Vector2D &rhs) 
{
	Vector2D res(lhs * rhs.x, lhs * rhs.y);
	return res;
}

int main() 
{
	Vector2D v1(1, 2);
	Vector2D v2(3, 4);
	Vector2D v3(1, 1);
	int b = 2;
	Vector2D v4 = 1 * ( v1 + v2 ) * 2 - v3;
	cout << "v4.x��" << v4.x << " v4.y��" << v4.y << endl;
	return 0;
}