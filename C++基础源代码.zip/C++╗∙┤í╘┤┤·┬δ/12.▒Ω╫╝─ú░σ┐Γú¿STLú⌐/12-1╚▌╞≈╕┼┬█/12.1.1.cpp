#include <iostream>
#include <vector>
using namespace std;
// ������
int main() 
{
	vector<int> vec;
	for ( int i = 0; i < 5; i++ ) 
	{
		int num = 0;
		cin >> num;
		vec.push_back(num);
	}
	vector<int>::iterator it = vec.begin();
	for ( ; it != vec.end(); it++ ) 
	{
		cout << *it << endl;
	}
	return 0;
}