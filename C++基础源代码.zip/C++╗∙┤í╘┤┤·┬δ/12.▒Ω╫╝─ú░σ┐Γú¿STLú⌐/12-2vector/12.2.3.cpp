#include <iostream>
#include <vector>
using namespace std;
// ������ʧЧ
void print(const vector<int> &vec) 
{
	for ( int i = 0; i < vec.size(); i++ ) 
	{
		cout << vec[i] << " ";
	}
	cout << endl;
}
int main() 
{
	vector<int> vec;
	cout << "��ʼ��vec��" << endl;
	for ( int i = 0; i < 10; i++ ) 
	{
		vec.push_back(i);
	}
	print(vec);
	cout << "�Ƴ�����Ԫ�أ�" << endl;
	int cnt = 0;
	vector<int>::iterator it = vec.begin();
	for ( ; it != vec.end(); cnt++, it++ ) 
	{
		if ( cnt % 2 == 1 ) 
		{
			vec.erase(it);
		}
		print(vec);
	}
	return 0;
}