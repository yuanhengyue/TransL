#include <iostream>
#include <vector>
#include <set>
#include <numeric>
using namespace std;
// ����㷨
int main() 
{
	set<int> set1;
	set1.insert(1);
	set1.insert(2);
	set1.insert(3);
	cout << "set1��Ԫ��֮��Ϊ��" << accumulate(set1.begin(), set1.end(), 0) << endl;
	vector<int> vec1;
	vec1.push_back(1);
	vec1.push_back(2);
	vec1.push_back(3);
	cout << "vec1��Ԫ��֮��Ϊ��" << accumulate(vec1.begin(), vec1.end(), 1) << endl;
	return 0;
}