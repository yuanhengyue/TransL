#include <iostream>
using namespace std;
// ��������
float badDotProduct(float x1, float y1, float z1, float x2, float y2, float z2) 
{
	return x1 * x2 + y1 * y2 + z1 * z2;
}
struct Vec3D 
{
	Vec3D(float X, float Y, float Z): x(X), y(Y), z(Z) {}
	float x;
	float y;
	float z;
};
float goodDotProduct(const Vec3D &v1, const Vec3D &v2) 
{
	return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
}
int main() 
{
	cout << badDotProduct(1.5f, 2.5f, 3.5f, 1.2f, 2.2f, 3.2f) << endl;
	cout << goodDotProduct(Vec3D(1.5f, 2.5f, 3.5f), Vec3D(1.2f, 2.2f, 3.2f)) << endl;
	return 0;
}