#include <iostream>
using namespace std;
// ������ת
// ����η�
int square(int num) 
{
	return num * num;
}
// �����η�
int cube(int num) 
{
	return num * num * num;
}
int moreJumpMath(int num) 
{
	if ( num % 2 ) 
	{
		return cube(num);
	} 
	else 
	{
		return square(num);
	}
}
inline int squareInl(int num) 
{
	return num * num;
}
inline int cubeInl(int num) 
{
	return num * num * num;
}
int lessJumpMath(int num) 
{
	return ( num % 2 ) ? cubeInl(num) : squareInl(num);
}
int main() 
{
	moreJumpMath(5);
	lessJumpMath(5);
	return 0;
}
