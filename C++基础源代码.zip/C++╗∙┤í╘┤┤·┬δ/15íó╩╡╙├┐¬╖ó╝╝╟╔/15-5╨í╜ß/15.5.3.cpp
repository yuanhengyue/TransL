#include <iostream>
using namespace std;
// ��������Ż�
void slowCondition(int num) 
{
	if ( num == 0 ) {
		cout << "��" << endl;
	} 
	else if ( num == 1 ) 
	{
		cout << "һ" << endl;
	} 
	else if ( num == 2 ) 
	{
		cout << "��" << endl;
	} 
	else if ( num == 3 ) 
	{
		cout << "��" << endl;
	} 
	else if ( num == 4 ) 
	{
		cout << "��" << endl;
	} 
	else if ( num == 5 ) 
	{
		cout << "��" << endl;
	} 
	else if ( num == 6 ) 
	{
		cout << "��" << endl;
	} 
	else if ( num == 7 ) 
	{
		cout << "��" << endl;
	} 
	else if ( num == 8 ) 
	{
		cout << "��" << endl;
	} 
	else if ( num == 9 ) 
	{
		cout << "��" << endl;
	} 
	else 
	{
		cout << "���ֲ���0-9��Χ�ڣ�" << endl;
	}
}
void fastCondition(int num) 
{
	switch ( num ) 
	{
	case 0:
		cout << "��" << endl;
		break;
	case 1:
		cout << "һ" << endl;
		break;
	case 2:
		cout << "��" << endl;
		break;
	case 3:
		cout << "��" << endl;
		break;
	case 4:
		cout << "��" << endl;
		break;
	case 5:
		cout << "��" << endl;
		break;
	case 6:
		cout << "��" << endl;
		break;
	case 7:
		cout << "��" << endl;
		break;
	case 8:
		cout << "��" << endl;
		break;
	case 9:
		cout << "��" << endl;
		break;
	default:
		cout << "���ֲ���0-9��Χ�ڣ�" << endl;
		break;
	}
}
int main() 
{
	int num = 5;
	slowCondition(5);
	fastCondition(5);
	return 0;
}
