#include <iostream>
using namespace std;
// ���ؾֲ����������
struct Interval 
{
	Interval(int b, int e): begin(b), end(e) {}
	int begin;
	int end;
};
Interval &buildInterval(int b, int e) 
{
	Interval intv(b, e);
	return intv;
}
int main() 
{
	Interval &intv = buildInterval(1, 2);
	cout << intv.begin << " " << intv.end << endl;
	return 0;
}