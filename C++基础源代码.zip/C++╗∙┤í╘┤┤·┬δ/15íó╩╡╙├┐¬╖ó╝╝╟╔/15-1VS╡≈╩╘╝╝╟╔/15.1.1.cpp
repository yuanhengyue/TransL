#include <iostream>
using namespace std;
// ����ָ��
void helloWorld() 
{
	cout << "Hello World!" << endl;
}
void zeroOneSchool() 
{
	cout << "��Ҽ��ѧ!" << endl;
}
int main() 
{
	helloWorld();
	zeroOneSchool();
	return 0;
}