#include <iostream>
using namespace std;
// �����ϵ�
int main() 
{
	for ( int i = 0; i < 10; i++ ) 
	{
		cout << i << endl;
	}
	return 0;
}