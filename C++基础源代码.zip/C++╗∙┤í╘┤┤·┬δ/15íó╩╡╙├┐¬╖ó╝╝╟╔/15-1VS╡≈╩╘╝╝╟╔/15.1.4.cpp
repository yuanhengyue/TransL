#include <iostream>
using namespace std;
// ����ջ

void func2() 
{
	cout << "func2��" << endl;
}
void func4() 
{
	cout << "func4��" << endl;
}
void func3() 
{
	func4();
	cout << "func3��" << endl;
}
void func1() 
{
	func2();
	cout << "func1��" << endl;
	func3();
}
int main() 
{
	func1();
	return 0;
}