#include <iostream>
#include <string>
using namespace std;
// ��ȡString�е��ַ�
int main() {
	string s = "Hello World!";
	for ( int i = 0; i < s.length(); i++ ) 
	{
		if ( i % 2 ) 
		{
			cout << s[i];
		}
	}
	cout << endl;
	return 0;
}