#include <iostream>
#include <vector>
using namespace std;
//1����Vector����Ԫ��
int main() 
{
	vector<int> vec1;
	if ( vec1.empty() ) 
	{
		cout << "vec1 is empty!" << endl;
	}
	vec1.push_back(1);
	vec1.push_back(2);
	if ( vec1.empty() ) 
	{
		cout << "vec1 is empty!" << endl;
	}
	for ( int i = 0; i < vec1.size(); i++ ) 
	{
		cout << vec1[i] << endl;
	}
	return 0;
}

#include <iostream>
#include <vector>
using namespace std;
//2����Vector�Ƴ�Ԫ��
int main() {
	vector<int> vec1(3, 2);
	for ( int i = 0; i < vec1.size(); i++ ) 
	{
		cout << vec1[i] << " ";
	}
	cout << endl;

	vec1.pop_back();
	vec1.pop_back();
	for ( int i = 0; i < vec1.size(); i++ ) 
	{
		cout << vec1[i] << " ";
	}
	cout << endl;
	return 0;
}

#include <iostream>
#include <vector>
using namespace std;
//3��Vector����ж��븳ֵ
int main() 
{
	vector<int> vec1(3, 2);
	vector<int> vec2;
	if ( vec1 == vec2 ) 
	{
		cout << "vec1��vec2���" << endl;
	}
	vec2 = vec1;
	cout << "��ֵ��" << endl;
	if ( vec1 == vec2 ) 
	{
		cout << "vec1��vec2���" << endl;
	}
	return 0;
}