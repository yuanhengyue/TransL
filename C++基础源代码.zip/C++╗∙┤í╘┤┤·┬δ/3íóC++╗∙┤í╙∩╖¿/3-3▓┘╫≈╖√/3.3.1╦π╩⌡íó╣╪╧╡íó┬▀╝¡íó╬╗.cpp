#include <iostream>
using namespace std;
//1������������
int main() 
{
	int a = 5;
	int b = 2;
	cout << "+ a: " << (+a) << endl;
	cout << "- a: " << (-a) << endl;
	cout << "a + b: " << (a + b) << endl;
	cout << "a - b: " << (a - b) << endl;
	cout << "a * b: " << (a * b) << endl;
	cout << "a / b: " << (a / b) << endl;
	cout << "a % b: " << (a % b) << endl;
	return 0;
}

#include <iostream>
using namespace std;
//2����ϵ������
int main() 
{
	int a = 5;
	int b = 2;
	int one = 1;
	bool t = true;
	cout << "a > b: " << (a > b) << endl;
	cout << "a < b: " << (a < b) << endl;
	cout << "a >= b: " << (a >= b) << endl;
	cout << "a <= b: " << (a <= b) << endl;
	cout << "t == one: " << (t == one) << endl;
	cout << "t != one: " << (t != one) << endl;
	return 0;
}

#include <iostream>
using namespace std;
//3���߼�������
int main() 
{
	cout << "true && true: " << (true && true) << endl;
	cout << "true && false: " << (true && false) << endl;
	cout << "false && false: " << (false && false) << endl;
	cout << "true || true: " << (true || true) << endl;
	cout << "true || false: " << (true || false) << endl;
	cout << "false || false: " << (false || false) << endl;
	cout << "!true: " << !true << endl;
	cout << "!false: " << !false << endl;
	return 0;
}

#include <iostream>
using namespace std;
//4���߼����ϵ�����������ʹ��
int main() 
{
	int a = 2;
	int b = 5;
	cout << "a < 3 && b < 3: " << (a < 3 && b < 3) << endl;
	cout << "a < 3 || b < 3: " << (a < 3 || b < 3) << endl;
	cout << "a < 3 && !(b < 3): " << (a < 3 && !(b < 3)) << endl;
	return 0;
}

#include <iostream>
using namespace std;
//5��λ������
int main() 
{
	int a = 1; // 0b01
	int b = 3; // 0b11
	cout << "a & b: " << (a & b) << endl; //ͬʱΪ1��Ϊ1����0����0
	cout << "a | b: " << (a | b) << endl; //��1���������1
	cout << "a ^ b: " << (a ^ b) << endl; //�����ͬΪ0����ͬΪ1
	cout << "~a: " << ~a << endl;//��
	return 0;
}