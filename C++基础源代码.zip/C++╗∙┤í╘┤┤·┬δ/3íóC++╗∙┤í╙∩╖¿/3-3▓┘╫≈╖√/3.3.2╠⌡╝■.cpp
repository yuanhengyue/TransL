#include <iostream>
using namespace std;
//1������������
int main() 
{
	int a = 3;
	int b = 2;
	int c = 5;
	int max = a > b ? a : b;
	int min = a < c ? a : c;
	cout << "max: " << max << endl;
	cout << "min: " << min << endl;
	return 0;
}

#include <iostream>
using namespace std;
//2��Ƕ������������
int main() 
{
	int a = 3;
	int b = 2;
	int c = 5;
	int max = a > b ? (a > c ? a : c ) : (b > c ? b : c);
	int min = a < b ? (a < c ? a : c ) : (b < c ? b : c);
	cout << "max: " << max << endl;
	cout << "min: " << min << endl;
	return 0;
}