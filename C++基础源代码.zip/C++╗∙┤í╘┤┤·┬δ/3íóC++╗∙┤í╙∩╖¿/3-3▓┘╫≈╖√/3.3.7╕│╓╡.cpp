#include <iostream>
using namespace std;
// ��ֵ������
int main() 
{
	int a = 3;
	int b = 2;
	cout << "a += b: " << (a += b) << endl;
	cout << "a -= b: " << (a -= b) << endl;
	cout << "a *= b: " << (a *= b) << endl;
	cout << "a /= b: " << (a /= b) << endl;
	cout << "a %= b: " << (a %= b) << endl;
	cout << "a <<= b: " << (a <<= b) << endl;
	cout << "a >>= b: " << (a >>= b) << endl;
	cout << "a &= b: " << (a &= b) << endl;
	cout << "a ^= b: " << (a ^= b) << endl;
	cout << "a |= b: " << (a |= b) << endl;
	return 0;
}