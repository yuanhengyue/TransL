#include <iostream>
using namespace std;
// �����Լ�������
int main() 
{
	int a = 2;
	cout << "a = " << a << endl;
	cout << "++a: " << ++a << endl;
	cout << "a++: " << a++ << endl;
	cout << "--a: " << --a << endl;
	cout << "a--: " << a-- << endl;
	return 0;
}