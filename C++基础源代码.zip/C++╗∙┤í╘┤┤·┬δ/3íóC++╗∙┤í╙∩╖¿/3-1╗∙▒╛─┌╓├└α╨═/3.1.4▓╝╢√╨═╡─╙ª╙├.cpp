#include <iostream>
using namespace std;

//�����͵�Ӧ��
int main() 
{
	cout << "�ռ�" << sizeof(bool) << "�ֽڡ�" << endl;
	
	bool trueFlag = true;
	bool falseFlag = false;
	cout << "a" << trueFlag << "��" << falseFlag << endl;
	
	trueFlag = 2;
	falseFlag = 0;
	cout << "b" << trueFlag << "��" << falseFlag << endl;
	cout << "c��" << trueFlag + 1 + falseFlag << endl;
	return 0;
}