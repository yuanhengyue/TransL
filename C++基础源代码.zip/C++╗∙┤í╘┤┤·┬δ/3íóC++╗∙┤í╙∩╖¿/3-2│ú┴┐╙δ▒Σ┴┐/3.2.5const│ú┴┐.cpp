#include <iostream>
using namespace std;
// const����
int main() 
{
	const int a = 1;
	a = 2;
	return 0;
}
