// ���ʿ��Ʒ�
// ����
class Base
{
	int a;
public:
	Base() : a(0), b(0), c(0), d(0) { }
	int getA() { return a; }
	int b;
protected:
	int c;
private:
	int getD() { return d; }
	int d;
};
// ������
class Derived : public Base
{
public:
	Derived() : Base(), e(0) { }
	int getC() { return c; }
private:
	int e;
};
int main() 
{
	Derived derived;
	int result = derived.b + derived.getA() + derived.getC();
	return 0;
}