#include <iostream>
#include <string>
using namespace std;
// ��ľ�̬��Ա����
class Student
{
public: 
	Student(int id, string name) : id(id), name(name) 
	{}
	static int generateId() 
	{
		return globalID++;
	}
	string getName() 
	{
		return name;
	}
	int getId() 
	{
		return id;
	}
private:
	string name;
	int id;
	static int globalID;
};

int Student::globalID = 1;

int main() 
{
	Student stu1(Student::generateId(), "С��");
	cout << stu1.getName() << "��ѧ��Ϊ��" << stu1.getId() << endl;
	Student stu2(Student::generateId(), "��");
	cout << stu2.getName() << "��ѧ��Ϊ��" << stu2.getId() << endl;
	return 0;
}