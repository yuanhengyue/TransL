#include <iostream>
using namespace std;
// ʹ��������ĳ�Ա
class B
{
public:
	B() { }
	static void printB() { cout << "print B!" << endl; }
};
class A
{
public:
	A() {}
	void printB() { B::printB(); }
private:
	int num;
};

int main() 
{
	A a;
	a.printB();
	return 0;
}