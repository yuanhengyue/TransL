#include <iostream>
using namespace std;
// ��ʼ���б�
class Time
{
public: 
	Time(int hr, int min, int sec) : hour(hr), minute(min), second(sec) {}
	int getHour() { return hour; }
	int getMinute() { return minute; }
	int getSecond() { return second; }
private:
	int hour;
	int minute;
	int second;
};

int main() 
{
	Time time(12, 24, 36);
	cout << "ʱ���ǣ�" << time.getHour() << "ʱ" 
		               << time.getMinute() << "��" 
		               << time.getSecond() << "��" << endl;
	return 0;
}