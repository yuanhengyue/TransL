#include <iostream>
using namespace std;

// Ĭ�Ϲ��캯��
class Time
{
public: 
	Time() 
	{
		hour = 0;
		minute = 0;
		second = 0;
	}
	int hour;
	int minute;
	int second;
};
int main() 
{
	Time time;
	cout << "ʱ���ǣ�" << time.hour << "ʱ" << time.minute << "��" << time.second << "��" << endl;
	return 0;
}