#include <iostream>
using namespace std;
// ��ʽ���캯��
class MyClass 
{
public:
	explicit MyClass(int n) : num(n) {}
	int getNum() { return num; }
private:
	int num;
};
int main() 
{
	MyClass my = 5;
	cout << "my��num��ֵΪ��" << my.getNum() << endl;
	return 0;
}