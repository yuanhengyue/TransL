#include <iostream>
using namespace std;
// ���
struct MyStruct1
{
	bool b1;
	bool b2;
	int i1;
};
struct MyStruct2 
{
	bool b1;
	int i1;
	bool b2;
};
struct MyStruct3 
{
	bool b1;
	short s1;
};
int main() 
{
	MyStruct1 s1;
	MyStruct2 s2;
	MyStruct3 s3;
	cout << "MyStruct1�Ĵ�СΪ��" << sizeof(s1) << endl;
	cout << "MyStruct2�Ĵ�СΪ��" << sizeof(s2) << endl;
	cout << "MyStruct3�Ĵ�СΪ��" << sizeof(s3) << endl;
	return 0;
}