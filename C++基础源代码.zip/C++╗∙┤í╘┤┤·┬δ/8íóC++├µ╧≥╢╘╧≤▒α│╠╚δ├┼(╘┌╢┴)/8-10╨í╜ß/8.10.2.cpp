#include <iostream>
using namespace std;
// ����Ĵ�С
class MyClass 
{
public:
	MyClass() {};
private:
};
int main() 
{
	MyClass myClass;
	cout << "myClass�Ĵ�СΪ��" << sizeof(myClass) << endl;
	return 0;
}