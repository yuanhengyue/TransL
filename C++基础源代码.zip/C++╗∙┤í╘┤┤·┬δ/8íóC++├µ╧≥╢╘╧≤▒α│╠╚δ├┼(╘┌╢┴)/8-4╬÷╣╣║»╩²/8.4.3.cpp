#include <iostream>
using namespace std;
// ���ڲ���̬�ڴ����
class MyClass
{
public: 
	MyClass(int size) : size(size) 
	{ 
		arr = new int[size]; 
		for ( int i = 0; i < size; i++ ) 
		{
			arr[i] = i;
		}
	}
	~MyClass() 
	{ delete[] arr; }
	void printArr() 
	{
		for ( int i = 0; i < size; i++ ) 
		{
			cout << arr[i] << " ";
		}
		cout << endl;
	}
private:
	int *arr;
	int size;
};

int main() 
{
	MyClass obj(5);
	obj.printArr();
	return 0;
}