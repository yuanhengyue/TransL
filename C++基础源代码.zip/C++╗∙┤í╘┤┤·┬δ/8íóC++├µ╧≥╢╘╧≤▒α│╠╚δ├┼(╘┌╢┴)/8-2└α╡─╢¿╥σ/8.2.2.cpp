#include <iostream>
#include <string>
using namespace std;
// ��Ա���������������ķ���
class Champion
{
public:
	Champion(int id, string nm, int hp, int mn, int dmg);
	void attack(Champion &);
	void takeDamage(int incomingDmg);
private:
	int ID;
	string name;
	int HP; //Ѫ��
	int mana; //ħ��ֵ
	int damage; //�˺�ֵ
};

Champion::Champion(int id,
				   string nm,
				   int hp,
				   int mn,
				   int dmg) 
{
	ID = id;
	name = nm;
	HP = hp;
	mana = mn;
	damage = dmg;
}
void Champion::attack(Champion &chmp) 
{
	chmp.takeDamage(this->damage);
}
void Champion::takeDamage(int incomingDmg) 
{
	HP -= incomingDmg;
}

int main() 
{
	return 0;
}