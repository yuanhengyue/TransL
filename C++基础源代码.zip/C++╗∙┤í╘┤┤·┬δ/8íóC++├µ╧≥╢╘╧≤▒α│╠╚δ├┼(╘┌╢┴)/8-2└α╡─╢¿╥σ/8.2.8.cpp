#include <iostream>
using namespace std;
// thisָ����Ϊ����ֵ
class MyClass
{
public:
	MyClass(int a, int b) 
	{
		this->a = a;
		this->b = b;
	}
	MyClass *getAddr() 
	{
		return this;
	}
	MyClass getCopy() 
	{
		return *this;
	}
	int getA() 
	{
		return a;
	}
private:
	int a;
	int b;
};
int main() 
{
	MyClass myclass(2, 3);
	MyClass *ptr = myclass.getAddr();
	cout << "a��ֵ�ǣ�" << ptr->getA() << endl;
	MyClass copy = myclass.getCopy();
	cout << "a��ֵ�ǣ�" << copy.getA() << endl;
	return 0;
}