#include <iostream>
using namespace std;
// thisָ�����ʽʹ��
class MyClass
{
public:
	MyClass(int a, int b) 
	{
		this->a = a;
		this->b = b;
	}
	int getA() 
	{
		return this->a;
	}
private:
	int a;
	int b;
};
int main() 
{
	MyClass myclass(2, 3);
	cout << "a��ֵ�ǣ�" << myclass.getA() << endl;
	return 0;
}