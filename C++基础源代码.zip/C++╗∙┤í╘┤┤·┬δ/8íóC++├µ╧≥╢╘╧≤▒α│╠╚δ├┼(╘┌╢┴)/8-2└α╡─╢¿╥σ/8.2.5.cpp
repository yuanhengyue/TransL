#include <iostream>
#include <string>
using namespace std;
// ��ָ����ʶ����Ա
class Champion
{
public:
	Champion(int id, string nm, int hp, int mn, int dmg) 
	{
		ID = id;
		name = nm;
		HP = hp;
		mana = mn;
		damage = dmg;
	}
	void attack(Champion &chmp) 
	{
		chmp.takeDamage(this->damage);
	}
	void takeDamage(int incomingDmg) 
	{
		HP -= incomingDmg;
	}
	int getHP() 
	{
		return HP;
	}
private:
	int ID;
	string name;
	int HP; //Ѫ��
	int mana; //ħ��ֵ
	int damage; //�˺�ֵ
};
int main() 
{
	Champion galen(1, "Galen", 800, 100, 10);
	Champion ash(2, "Ash", 700, 150, 7);
	cout << "Ash�ĳ�ʼѪ����" << ash.getHP() << endl;
	Champion *chmpPtr = &galen; // ָ��Champion��ָ��
	(*chmpPtr).attack(ash);
	chmpPtr->attack(ash);
	cout << "Ash�ܵ�Galen�������Ѫ����" << ash.getHP() << endl;
	return 0;
}