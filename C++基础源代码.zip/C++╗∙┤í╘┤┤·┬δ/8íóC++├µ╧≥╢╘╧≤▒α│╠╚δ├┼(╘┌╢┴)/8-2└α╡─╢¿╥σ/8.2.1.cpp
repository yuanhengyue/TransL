#include <iostream>
#include <string>
using namespace std;
// ��Ķ���
class Champion
{
public:
	Champion(int id,
			 string nm,
			 int hp,
			 int mn,
			 int dmg) 
	{
		ID = id;
		name = nm;
		HP = hp;
		mana = mn;
		damage = dmg;
	}
	void attack(Champion &chmp) 
	{
		chmp.takeDamage(this->damage);
	}
	void takeDamage(int incomingDmg) 
	{
		HP -= incomingDmg;
	}
private:
	int ID;
	string name;
	int HP; //Ѫ��
	int mana; //ħ��ֵ
	int damage; //�˺�ֵ
};
int main() 
{
	return 0;
}