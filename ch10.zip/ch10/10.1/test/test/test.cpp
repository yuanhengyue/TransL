﻿// test.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include <iostream>

#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdlib.h>
#include <stdio.h>

using namespace cv;
#pragma comment(lib, "opencv_world450d.lib")  //引用引入库 

int main()
{
	Mat img, dst;
	//读取原始图像
	img = imread("img.jpg", IMREAD_COLOR);

	//图像向下取样
	pyrDown(img, dst);
	//显示图像
	imshow("original", img);
	imshow("PyrDown", dst);
	waitKey(0);
	destroyAllWindows();
} 